using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WowGMSBackend.Interfaces;
using WowGMSBackend.Model;
using WowGMSBackend.Service;

namespace WoWGMS.Pages
{
    public class EditRosterModel : PageModel
    {

        private readonly IRosterService _rosterService;

        public EditRosterModel( IRosterService rosterService)
        {

            _rosterService = rosterService;
        }

        [BindProperty]
        public BossRoster Roster { get; set; }

        public List<Character> EligibleCharacters { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            Roster = _rosterService.GetRosterById(id);
            if (Roster == null) return NotFound();

            EligibleCharacters = _rosterService.GetEligibleCharacters(Roster);
            return Page();
        }

        public IActionResult OnPost(int id)
        {
            _rosterService.UpdateRosterTime(id, Roster.InstanceTime);
            return RedirectToPage("/Roster");
        }


        public IActionResult OnPostAdd(int id, int characterId)
        {
            var character = _rosterService.GetCharacterById(characterId); // you'll add this helper if needed
            if (character == null) return RedirectToPage(new { id });

            try
            {
                _rosterService.AddCharacterToRoster(id, character);
            }
            catch (InvalidOperationException)
            {
                // ignore duplicate
            }

            return RedirectToPage(new { id });
        }

        public IActionResult OnPostRemove(int id, int participantId)
        {
            _rosterService.RemoveCharacterFromRoster(id, participantId);
            return RedirectToPage(new { id });
        }


    }
}
