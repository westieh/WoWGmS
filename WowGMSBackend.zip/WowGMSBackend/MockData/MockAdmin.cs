﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WowGMSBackend.MockData
{
    public static class MockAdmin
    {
        public static string Username => "admin";
        public static string Password => "password123";
        public static string Role => "Admin";
    }
}
