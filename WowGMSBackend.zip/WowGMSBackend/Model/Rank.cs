﻿namespace WowGMSBackend.Model
{
    public enum Rank
    {
        Trialist,
        Raider,
        Officer
    }
}
