﻿namespace WowGMSBackend.Model
{
    public enum Role
    {
        Tank,
        Healer,
        MeleeDPS,
        RangedDPS
    }
}
