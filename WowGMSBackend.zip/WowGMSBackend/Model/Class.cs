﻿namespace WowGMSBackend.Model
{
    public enum Class
    {
        Mage,
        Warrior,
        Rogue,
        Monk,
        Priest,
        DeathKnight,
        Evoker,
        Druid,
        Warlock,
        Paladin,
        Hunter,
        Shaman,
        DemonHunter
    }
}
